    <div class="footer mt-4 bg-dark text-white pt-3 pb-2">
      <div class="container">
        <center>@Copyright by 21552011088_Kelompok 8_TIFRP221-PA_UASWEB1</center>
        <!-- Copyright <?= date('Y'); ?> <?= $info_web->nama_rental; ?> -->


      </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    </body>

    </html>