<?php

$user = 'root';
$pass = '';

$koneksi = new PDO("mysql:host=localhost;dbname=db_rental_mobil", $user, $pass);

global $url;
$url = "http://localhost/PEMROGRAMAN_WEB_1/rental_mobil_web/";

$sql_web = "SELECT * FROM infoweb WHERE id = 1";
$row_web = $koneksi->prepare($sql_web);
$row_web->execute();
global $info_web;
$info_web = $row_web->fetch(PDO::FETCH_OBJ);

error_reporting(0);


$conn = mysqli_connect("localhost", "root", "", "db_rental_mobil");
function registrasi($data)
{
    global $conn;

    $nama = mysqli_real_escape_string($conn, $data["name"]);
    $email = strtolower(stripslashes($data["email"]));
    $password = mysqli_real_escape_string($conn, $data["pass"]);
    $password2 = mysqli_real_escape_string($conn, $data["re_pass"]);

    mysqli_query($conn, "INSERT INTO user VALUES('','$nama','$email','$password')");

    return mysqli_affected_rows($conn);
}

function check_login_limit($username, $conn)
{
    $sql = "SELECT login_attempts FROM users WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $login_attempts = $row['login_attempts'];
        if ($login_attempts >= 3) {
            return true;
        }
    }
    return false;
}